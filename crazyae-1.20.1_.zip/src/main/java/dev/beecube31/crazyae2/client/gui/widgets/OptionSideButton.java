package dev.beecube31.crazyae2.client.gui.widgets;

import dev.beecube31.crazyae2.client.components.ColorContainer;
import dev.beecube31.crazyae2.client.gui.sprite.StateSprite;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;

import java.util.function.Supplier;

public class OptionSideButton extends WidgetBase {
    public enum ButtonType {
        DEFAULT(StateSprite.OPTION_SIDE_BUTTON),
        NO_TOP(StateSprite.OPTION_SIDE_BUTTON_NO_TOP),
        NO_BOTTOM(StateSprite.OPTION_SIDE_BUTTON_NO_BOTTOM),
        NO_TOP_BOTTOM(StateSprite.OPTION_SIDE_BUTTON_NO_TOP_BOTTOM);

        private final StateSprite background;

        ButtonType(StateSprite background) {
            this.background = background;
        }
    }

    private StateSprite icon;
    private final ButtonType type;
    private final Supplier<ColorContainer> hue;
    private final Runnable onPress;

    public OptionSideButton(StateSprite icon, Component tooltip, ButtonType type, Supplier<ColorContainer> hue,
            Runnable onPress) {
        super(0, 0, StateSprite.OPTION_SIDE_BUTTON.getSizeX(), StateSprite.OPTION_SIDE_BUTTON.getSizeY(), tooltip);
        this.icon = icon;
        this.type = type;
        this.hue = hue;
        this.onPress = onPress;
        this.setTooltipText(tooltip);
    }

    public void setIcon(StateSprite icon) {
        this.icon = icon;
    }

    public void setTooltipText(Component text) {
        this.setMessage(text);
        this.setTooltip(Tooltip.create(text));
    }

    @Override
    public void onPress() {
        this.onPress.run();
    }

    @Override
    public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        ColorContainer h = this.hue.get();
        this.type.background.getBlitter().copy()
                .color(h.getRed(), h.getGreen(), h.getBlue(), 1F)
                .dest(getX(), getY())
                .blit(guiGraphics);

        if (this.icon != null) {
            int dy = this.icon == StateSprite.ABC ? 7 : 3;
            this.icon.getBlitter().copy().dest(getX() + 3, getY() + dy).blit(guiGraphics);
        }
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
        this.defaultButtonNarrationText(narrationElementOutput);
    }
}
