package dev.beecube31.crazyae2.client.gui.widgets;

import appeng.client.gui.style.PaletteColor;
import appeng.client.gui.style.ScreenStyle;
import appeng.client.gui.widgets.AETextField;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

public class CrazyTextField extends AETextField {

    private Runnable onConfirm;

    private final int fontPadding;

    public CrazyTextField(ScreenStyle style, Font fontRenderer, int x, int y, int width, int height) {
        super(style, fontRenderer, x, y, width, height);

        this.fontPadding = fontRenderer.width("_");
    }

    @Override
    public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partial) {
        if (this.isVisible()) {
            var yOffset = 0;
            if (!this.isEditable()) {
                yOffset = 12;
            } else if (isFocused()) {
                yOffset = 24;
            }

            var bounds = getVisualBounds();

            BLITTER.src(0, yOffset, 1, 12)
                    .dest(bounds.left, bounds.top)
                    .blit(guiGraphics);
            var backgroundWidth = Math.min(126, bounds.right - bounds.left - 2);
            BLITTER.src(1, yOffset, backgroundWidth, 12)
                    .dest(bounds.left + 1, bounds.top)
                    .blit(guiGraphics);
            BLITTER.src(127, yOffset, 1, 12)
                    .dest(bounds.right - 1, bounds.top)
                    .blit(guiGraphics);

            super.renderWidget(guiGraphics, mouseX, mouseY, partial);

            // Render a placeholder value if the text field isn't focused and is empty
            if (placeholder != null && !isFocused() && getValue().isEmpty()) {
                var font = Minecraft.getInstance().font;
                guiGraphics.drawString(font, placeholder, getX(), getY(),
                        style.getColor(PaletteColor.TEXTFIELD_PLACEHOLDER).toARGB(), false);
            }
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (canConsumeInput() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            if (this.onConfirm != null) {
                this.onConfirm.run();
            }
            return true;
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private VisualBounds getVisualBounds() {
        int left = getX() - 2;
        int top = getY() - 2;
        int right = left + width + 2 * 2 + fontPadding;
        return new VisualBounds(
                left,
                top,
                right,
                top + height + 2 * 2);
    }

    public void setOnConfirm(Runnable onConfirm) {
        this.onConfirm = onConfirm;
    }

    private record VisualBounds(int left, int top, int right, int bottom) {}

}
