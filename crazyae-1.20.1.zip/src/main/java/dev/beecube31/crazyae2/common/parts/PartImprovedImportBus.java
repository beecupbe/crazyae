package dev.beecube31.crazyae2.common.parts;

import appeng.api.parts.IPartItem;
import appeng.api.parts.IPartModel;
import appeng.items.parts.PartModels;
import appeng.menu.MenuOpener;
import appeng.menu.implementations.IOBusMenu;
import appeng.menu.locator.MenuLocators;
import appeng.parts.PartModel;
import appeng.parts.automation.ImportBusPart;
import dev.beecube31.crazyae2.common.interfaces.parts.ICrazyPart;
import dev.beecube31.crazyae2.common.util.ContainerOpener;
import dev.beecube31.crazyae2.core.CrazyAE;
import dev.beecube31.crazyae2.core.registries.server.CrazyContainers;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.phys.Vec3;

public class PartImprovedImportBus extends ImportBusPart implements ICrazyPart {
    @PartModels
    public static final ResourceLocation MODEL_BASE = CrazyAE.makeId("part/improved_import_bus_base");
    @PartModels
    public static final IPartModel MODELS_OFF = new PartModel(MODEL_BASE, new ResourceLocation("ae2", "part/import_bus_off"));
    @PartModels
    public static final IPartModel MODELS_ON = new PartModel(MODEL_BASE, new ResourceLocation("ae2", "part/import_bus_on"));
    @PartModels
    public static final IPartModel MODELS_HAS_CHANNEL = new PartModel(MODEL_BASE, new ResourceLocation("ae2", "part/import_bus_has_channel"));

    public PartImprovedImportBus(IPartItem<?> partItem) {
        super(partItem);
    }

    @Override
    public boolean onCrazyPartActivate(Player player, InteractionHand hand, Vec3 pos) {
        if (!isClientSide()) {
            ContainerOpener.open(getMenuType(), player, MenuLocators.forPart(this));
        }
        return true;
    }

    @Override
    protected MenuType<?> getMenuType() {
        return CrazyContainers.IMPROVED_IMPORT_BUS.get();
    }

    @Override
    protected int getOperationsPerTick() {
        return CrazyBusSpeed.operations(getUpgrades());
    }

    @Override
    public IPartModel getStaticModels() {
        if (this.isActive() && this.isPowered()) {
            return MODELS_HAS_CHANNEL;
        } else if (this.isPowered()) {
            return MODELS_ON;
        }
        return MODELS_OFF;
    }
}
