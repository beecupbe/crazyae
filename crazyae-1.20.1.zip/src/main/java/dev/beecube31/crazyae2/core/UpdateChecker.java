package dev.beecube31.crazyae2.core;

import appeng.util.Platform;
import com.google.common.base.Preconditions;
import dev.beecube31.crazyae2.common.i18n.CrazyAEGuiText;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.ClickEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class UpdateChecker {

    private static UpdateCheckThread thread;
    private static int delay = 50;
    private static boolean playerNotified = false;

    public UpdateChecker(String url) {
        try {
            new URL(url);
        } catch (MalformedURLException ex) {
            throw new IllegalArgumentException("Invalid URL provided");
        }
        thread = new UpdateCheckThread(url);
    }

    @SubscribeEvent
    public void tickStart(TickEvent.ClientTickEvent event) {

        if (delay > 0) {
            if (Minecraft.getInstance().level != null) {
                if (delay == 50) thread.start();
                delay--;
            }
        } else {
            if (!playerNotified && thread.shouldNotifyUser()) {
                playerNotified = true;

                if (Platform.isClient()) {
                    var updateString = CrazyAEGuiText.DOWNLOAD_LINK.getComponentWithSpaceAtEnd().withStyle(
                            style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, thread.getDownloadLink()))
                                    .withUnderlined(true));

                    Minecraft.getInstance().gui.getChat().addMessage(
                            CrazyAEGuiText.UPDATE_FOUND.getComponentWithSpaceAtEnd()
                                    .append(thread.getActualVersion())
                                    .append(thread.getUpdateDescription())
                    );

                    Minecraft.getInstance().gui.getChat().addMessage(updateString);
                    Minecraft.getInstance().gui.getChat().addMessage(CrazyAEGuiText.DISABLE_UPDATES_TIP.getComponent());
                }
            }
        }
    }

    public static class UpdateCheckThread extends Thread {
        private String actualVersion = null;
        private String description = "";
        private boolean isCheckingComplete = false;
        private boolean shouldNotifyUser = false;

        private String downloadLink = null;

        private String localizedDescInternalName;

        private final String URL;

        public UpdateCheckThread(String name) {
            URL = name;
        }

        public void run() {
            this.determineLocale(Minecraft.getInstance().getLocale().toString());
            CrazyAE.logger().info("[Update Checker] - Checking for update...");
            try {
                URL versionURL = new URL(URL);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(versionURL.openStream()));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    if (line.contains(":")) {
                        String value = line.substring(line.indexOf(":") + 1);

                        if (line.contains("version")) {
                            this.actualVersion = value;
                            continue;
                        }

                        if (line.contains(this.localizedDescInternalName)) {
                            this.description = value;
                            continue;
                        }

                        if (line.contains("link")) {
                            this.downloadLink = value;
                        }
                    }
                }
                if (this.downloadLink != null && this.actualVersion != null) {
                    this.isCheckingComplete = true;

                    if (this.actualVersion.equals(ModVersion.get())) {
                        CrazyAE.logger().info("[Update Checker] - Mod is up to date");
                        return;
                    }

                    this.shouldNotifyUser = true;
                    CrazyAE.logger().info("[Update Checker] - Update found: {} : {}. Current version {}", this.actualVersion, this.downloadLink, ModVersion.get());
                }

                CrazyAE.logger().info("[Update Checker] - Check success. Actual version: {}", getActualVersion());
            } catch (Exception e) {
                CrazyAE.logger().warn("[Update Checker] - Check failed: {}", e.getMessage());
            }
        }

        private void determineLocale(String l) {
            if (l.contains("ru")) {
                this.localizedDescInternalName = "desc_ru";
                return;
            }

            if (l.contains("zh")) {
                this.localizedDescInternalName = "desc_cn";
                return;
            }

            this.localizedDescInternalName = "desc";
        }

        public String getActualVersion() {
            return this.actualVersion;
        }

        public String getUpdateDescription() {
            return this.description;
        }

        public boolean shouldNotifyUser() {
            return this.shouldNotifyUser;
        }

        public String getDownloadLink() {
            return this.downloadLink;
        }

        public boolean isCheckingComplete() {
            return this.isCheckingComplete;
        }
    }
}
